"""
Hey man this is a really long message to see how flake8 likes lines longer than 80 chars.
"""

from setuptools import setup

setup(
  name="sample",
  version="1.0.0",
  description="peter smells",
  license="WTFPL"
)
